clc;
clear all;
beta=[0:0.02:0.5];
beta=[beta,fliplr(beta)];
Beta=[0:0.01:0.5];
Beta=[Beta,Beta];
I=load('Osimulation.txt');
O=load('Omtf.txt');
figure(1)
plot(Beta,I(1,:),'ko','MarkerFaceColor','k');
hold on 
plot(Beta,I(2,:),'o','Color','[0.47,0.67,0.19]','MarkerFaceColor','[0.47,0.67,0.19]');
plot(Beta,I(3,:),'ro','MarkerFaceColor','r');
% plot(Beta,I(4,:),'ko','MarkerFaceColor','k');
% plot(Beta,I(5,:),'go','MarkerFaceColor','g');
plot(beta,O(1,:),'k-','linewidth',1.5);
plot(beta,O(2,:),'-','Color','[0.47,0.67,0.19]','linewidth',1.5);
plot(beta,O(3,:),'r-','linewidth',1.5);
% plot(beta,O(4,:),'k-','linewidth',1.5);
% plot(beta,O(5,:),'g-','linewidth',1.5);
% plot(beta,O(6,:),'r-','linewidth',1.5);
hl=legend({'\nu=0.08 Sim','\nu=0.20 Sim','\nu=0.42 Sim','\nu=0.08 MF','\nu=0.20 MF','\nu=0.42 MF'},'FontName','Times New Roman','FontSize',10);
set(hl,'Box','off')
hold off
xlabel('\beta','FontSize',22,'FontName','Times New Roman');
ylabel('\rho^+','FontSize',22,'FontName','Times New Roman');
ax=gca;
ax.FontSize=16;
% figure(2)
% plot(beta,O(1,:),'k-','linewidth',1.5);
% hold on 
% plot(beta,O(2,:),'g-','linewidth',1.5);
% plot(beta,O(3,:),'r-','linewidth',1.5);
% plot(beta,O(4,:),'k-','linewidth',1.5);
% plot(beta,O(5,:),'g-','linewidth',1.5);
% plot(beta,O(6,:),'r-','linewidth',1.5);
% hold off
% xlabel('\beta');
% ylabel('��^+');