clc;
clear all;
S=load("Sim.mat");
T=load("Theoretic.mat");
plot(T.beta1,T.v1,'b-','linewidth',1.5)
hold on
plot(T.beta2,T.v2,'r-','linewidth',1.5)
plot(T.beta3,T.v3,'-','color','[0.47,0.67,0.19]','linewidth',1.5)
plot(S.Beta1,S.V1,'bs','MarkerSize',10)
plot(S.Beta2,S.V2,'ro','MarkerSize',10)
plot(S.Beta3,S.V3,'^','color','[0.47,0.67,0.19]','MarkerSize',10)
hold off
legend({'\gamma=0.1 MF','\gamma=0.3 MF','\gamma=0.5 MF','\gamma=0.1 Sim','\gamma=0.3 Sim','\gamma=0.5 Sim'},'Fontname','Times New Roman')
xlim([0,0.70])
ylim([0,0.70])
xlabel('\beta','FontSize',22,'FontName','Times New Roman')
ylabel('\nu','FontSize',22,'FontName','Times New Roman')
ax=gca;
ax.FontSize=16;
ax.XLim=[0 0.70];
ax.YLim=[0 0.70];