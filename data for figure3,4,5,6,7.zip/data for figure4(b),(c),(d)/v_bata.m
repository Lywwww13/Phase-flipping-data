clc;
clear all;
beta=[0:0.01:0.5];
v=[0.01:0.01:0.5];
y=[0.030,0.040,0.060,0.080,0.100,0.120,0.140,0.160,0.180,0.200,0.220,0.240,0.260,0.280,0.300,0.320,0.340,0.360,0.37,0.38,0.37,0.360,0.340,0.320,0.300,0.280,0.260,0.240,0.220,0.200,0.180,0.160,0.140,0.120,0.100,0.080,0.060,0.040];
x=[0.0,0.134,0.152,0.168,0.183,0.195,0.207,0.218,0.228,0.237,0.248,0.256,0.264,0.269,0.274,0.278,0.280,0.282,0.282,0.282,0.283,0.286,0.288,0.291,0.296,0.302,0.310,0.319,0.328,0.338,0.348,0.360,0.377,0.396,0.417,0.450,0.490,0.580];
yy=[0.03,0.05,0.07,0.10,0.13,0.15,0.17,0.20,0.22,0.25,0.29,0.34,0.38,0.38,0.35,0.31,0.27,0.24,0.22,0.19,0.17,0.14,0.12,0.10,0.08,0.06,0.05,0.04];
xx=[0.0,0.14,0.16,0.18,0.20,0.21,0.22,0.24,0.25,0.26,0.27,0.27,0.27,0.27,0.28,0.29,0.30,0.31,0.32,0.33,0.34,0.36,0.37,0.39,0.41,0.45,0.49,0.58];
infected=zeros(50,51);
opinion=zeros(50,51);
infectedforward=load('infectedforward.txt');
opinionforward=load('opinionforward.txt');
infectedbackward=load('infectedbackward.txt');
opinionbackward=load('opinionbackward.txt');
for i=1:50
    for j=1:51
        if abs(infectedforward(i,j)-infectedbackward(i,j)) > 0.1 || abs(opinionforward(i,j)-opinionbackward(i,j)) > 0.1
            infected(i,j) = 0;
        else
            infected(i,j)=(infectedforward(i,j)+infectedbackward(i,j))/2;
        end
    end
end
for i=1:50
    for j=1:51
        if abs(opinionforward(i,j)-opinionbackward(i,j)) > 0.1
            opinion(i,j) = 0;
        else
            opinion(i,j)=(opinionforward(i,j)+opinionbackward(i,j))/2;
        end
    end
end
err_level=0.00;%�������
xt=0:0.01:0.50;%����x����
yt=0:0.01:0.50;%����y����
n=length(xt);
X=zeros(4,(n-1)*(n-1));
Y=zeros(4,(n-1)*(n-1));
C=zeros(1,(n-1)*(n-1),3);
D=zeros(1,(n-1)*(n-1),3);
Emax=max(max(opinion));
Emin=min(min(opinion));
emax=max(max(infected));%Er�����ֵ
emin=min(min(infected));%Er����Сֵ
MAPX=jet((n-1)*(n-1));%��jet��ɫ������չ����һ��Ҫ��Ҫ��ϵ����
lenMAPX=length(MAPX);
for i=1:n-1
    for j=1:n-1
        X(1,100*(i-1)+j)=xt(i);
        X(2,100*(i-1)+j)=xt(i)+0.01;%����Xλ�þ���
        X(3,100*(i-1)+j)=xt(i)+0.01;
        X(4,100*(i-1)+j)=xt(i);
        
        Y(1,100*(i-1)+j)=yt(j);
        Y(2,100*(i-1)+j)=yt(j);%����Yλ�þ���
        Y(3,100*(i-1)+j)=yt(j)+0.01;
        Y(4,100*(i-1)+j)=yt(j)+0.01;
        
        if infected(i,j)<=err_level;
            C(1,100*(i-1)+j,:)=[1,1,1];%�����λ�ö�Ӧ��ErֵС��err_level���Ű�ɫ
        else%Er����0.05��ֵ����colormap������ȷ����ɫ
            kk=(emax-infected(i,j))/(infected(i,j)-emin);
            ind=round((lenMAPX+kk)/(kk+1));
            C(1,100*(i-1)+j,:)=MAPX(ind,:);   
        end
        if opinion(i,j)<=err_level;
            D(1,100*(i-1)+j,:)=[1,1,1];
        else
            kk=(Emax-opinion(i,j))/(opinion(i,j)-Emin);
            ind=round((lenMAPX+kk)/(kk+1));
            D(1,100*(i-1)+j,:)=MAPX(ind,:);
        end
    end
end
values=spcrv([[x(1) x x(end)];[y(1) y y(end)]],3);
figure(1)
h=pcolor(beta,v,opinionforward);
set(h,'edgecolor','none');
xlabel('\beta');
ylabel('v');
colorbar;
figure(2)
s=pcolor(beta,v,opinionbackward);
set(s,'edgecolor','none');
xlabel('\beta');
ylabel('v');
colorbar;
figure(3)
f=patch(Y,X,C);
set(f,'edgecolor','none');
xlabel('\beta','FontSize',22,'FontName','Times New Roman');
ylabel('\nu','FontSize',22,'FontName','Times New Roman');
colormap jet;
c2=colorbar;
c2.Label.String=('\rho^R');
c2.Label.FontName='Times New Roman';
c2.Label.FontSize=22;
ax=gca;
ax.FontSize=16;
%set(get(c2,'ylabel'),'string','��^R','fontsize',14,'FontName','Times New Roman')
caxis([emin,emax]);
figure(4)
l=patch(Y,X,D);
set(l,'edgecolor','none');
hold on 
%plot(values(1,:),values(2,:),'b-','linewidth',1.5);
xlim([0 0.50])
ylim([0 0.50]);
xlabel('\beta','FontSize',22,'FontName','Times New Roman');
ylabel('\nu','FontSize',22,'FontName','Times New Roman');
colormap jet;
c1=colorbar;
c1.Label.String=('\rho^+');
c1.Label.FontName='Times New Roman';
c1.Label.FontSize=22;
ax=gca;
ax.FontSize=16;
caxis([Emin,Emax]);
figure(5)
% plot(x,y,'rs')
% hold on 
plot(values(1,:),values(2,:),'b-','linewidth',1.5);
hold on 
plot(xx,yy,'rs','MarkerSize',10);
hold off
legend({'MF','Simulation'},'FontName','Times New Roman','FontSize',10)
%plot(xx,yy,'b-');
% x1=0.05:0.01:0.50;
% y1=interp1(xx,y,x1,'cubic');
% plot(x1,y1,'b-')
xlim([0 0.50])
ylim([0 0.50]);
hold off
xlabel('\beta','FontSize',22,'FontName','Times New Roman');
ylabel('\nu','FontSize',22,'FontName','Times New Roman');
ax=gca;
ax.FontSize=16;