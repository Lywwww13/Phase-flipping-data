clc;
clear all;
%load v1_v2.mat;
v1=[0.01,0.05,0.10,0.11,0.12,0.13,0.14,0.15,0.16,0.17,0.18,0.19,0.20,0.22,0.24,0.26,0.28,0.30,0.32,0.33,0.335,0.337,0.342,0.337,0.335,0.33,0.32,0.31,0.30,0.29,0.28,0.27,0.26,0.25,0.24,0.23,0.22,0.21,0.20,0.19];
v2=[0.147,0.168,0.194,0.2,0.205,0.210,0.216,0.222,0.228,0.234,0.240,0.247,0.253,0.267,0.281,0.295,0.311,0.327,0.345,0.354,0.359,0.361,0.364,0.356,0.352,0.345,0.331,0.315,0.296,0.277,0.257,0.237,0.212,0.187,0.160,0.135,0.110,0.08,0.04,0.01];
r1=[0.5,0.6,0.7,0.8,0.9,1.0,1.1];
r2=[0.61,0.65,0.67,0.684,0.697,0.709,0.72];
P=load('PT2.txt');
A=load('ActiveNoisy.txt');
N=load('NegativeNoisy.txt');
A1=load('ActiveNoisy1.txt');
N1=load('NegativeNoisy1.txt');
t=0.1:0.1:6000;
figure(1)
plot(v1,v2,'b-','linewidth',1.5)
hold on
plot(A(30000:31675),N(30000:31675),'k-')
%plot(A(50000:52500),N(50000:52500),'k-')
plot(0.2,0.2,'ko','MarkerSize',15,'MarkerFaceColor','y')
plot(A(5970),N(5970),'ko','MarkerSize',15','MarkerFaceColor','g')
plot(A(31675),N(31675),'ko','MarkerSize',15,'MarkerFaceColor','r')
plot(A(36687),N(36687),'ko','MarkerSize',15,'MarkerFaceColor','g')
plot(A(52500),N(52500),'ko','MarkerSize',15,'MarkerFaceColor','r')
hold off
xlabel('\nu^+','FontName','Times New Roman','FontSize',22)
ylabel('\nu^-','FontName','Times New Roman','FontSize',22)
xlim([0.01 0.5])
ylim([0.01 0.5])
ax=gca;
ax.FontSize=16;

figure(2)
plot(t(1:60000),P(1:60000),'-','Color','[0.08,0.17,0.55]')
hold on
plot(t(5970),P(5970),'ko','MarkerSize',15,'MarkerFaceColor','g')
plot(t(36687),P(36687),'ko','MarkerSize',15,'MarkerFaceColor','g')
plot(t(31675),P(31675),'ko','MarkerSize',15,'MarkerFaceColor','r')
plot(t(52507),P(52507),'ko','MarkerSize',15,'MarkerFaceColor','r')
hold off
xlabel('t','FontName','Times New Roman','FontSize',22)
ylabel('\rho^+(t)','FontName','Times New Roman','FontSize',22)
ax=gca;
ax.FontSize=16;

figure(3)
h=histogram(P,'Normalization','probability');
h.NumBins=20;
xlabel('\rho^+','FontName','Times New Roman','FontSize',22)
ylabel('Probability density','FontName','Times New Roman','FontSize',22)
ax=gca;
ax.FontSize=16;

figure(4)
plot(r1,r2,'b-','linewidth',1.5)
xlabel('r^+','FontName','Times New Roman','FontSize',14)
ylabel('r^-','FontName','Times New Roman','FontSize',14)
xlim([0.9 1.1])
ylim([0 1.5]) 

figure(5)
plot(v1,v2,'b-','linewidth',1.5)
hold on
plot(A1(500:end),N1(500:end),'k-')
hold off
xlabel('\nu^+','FontName','Times New Roman','FontSize',22)
ylabel('\nu^-','FontName','Times New Roman','FontSize',22)
xlim([0.01 0.45])
ylim([0.01 0.5])