clc;
clear all;
parpool;
N=500;
v=0.42;
forwardsolution=zeros(1,25);
backwardsolution=zeros(1,25);
parfor i=1:25
    i
    [A,R]=SIR(i*0.02);
    [a,r]=NV(v,i*0.02);
    deviation=ones(1,N+1);
    for m=1:N+1
        b=find(A == (m-1)*0.002);
        c=find(a == (m-1)*0.002);
        if(~isempty(c))
            deviation(m)=R(b)-r(c);
        end
    end
    x=0;
    for c=1:length(deviation)
        if(deviation(c)~= 1 && abs(deviation(c)) < 0.0031)
            forwardsolution(i) = c * 0.002;
            x=x+1;
            break;
        end
    end
    if (x == 0);
        forwardsolution(i) = find(abs(deviation) == min(abs(deviation))) * 0.002;
    end
    if(v <= 0.06 && (i-1)*0.02 <= 0.48 && forwardsolution(i) > 0.2)
        forwardsolution(i) = a(1);
    end

x=0;
for c=1:length(deviation)
    if(deviation(length(deviation)+1-c)~= 1 && abs(deviation(length(deviation)+1-c)) < 0.0031)
        backwardsolution(i) = (length(deviation)+1-c) * 0.002;
        x=x+1;
        break;
    end
end
if (x == 0);
    backwardsolution(i) = find(abs(deviation) == min(abs(deviation))) * 0.002;
end
end
delete(parpool);
% figure(1)
% plot(A,R,'b-','linewidth',1.5)
% hold on
% plot(a,r,'r-','linewidth',1.5)
% hold off
% xlabel('��^+')
% ylabel('��^R')
% ylim([0 1])