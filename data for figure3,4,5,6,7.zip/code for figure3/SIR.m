function [A,R] = SIR(beta)
A=[];
R=[];
k=10;
error=[];
N=500;
alpha=0.2;
for n = 1:N+1;
    A(n)=(n-1)*0.002;
    active=(n-1)*0.002;
    for m = 2:1001;
        removed=(m-1)*0.001;
        error(m-1)=abs(1-active*0.999*exp(-beta*k*removed)-(1-active)*0.999*exp(-alpha*beta*k*removed)-removed);
    end
    index=find(error == min(error));
    R(n)=(index-1)*0.001;
end
end