function [a,r] = NV(v,beta)
p=1;
N=500;
k=10;
alpha=0.2;
Gamma=0.1;
Error=[];
Index=[];
Number=zeros(1,N+1);
for i=1:N+1;
    Active=(i-1)*0.002;
    for ii = 1:1001
        removed=(ii-1)*0.001;
        Error(ii)=(1-(1-v*0.1)*(1-0.1*Gamma*p*sumfunction(10,4,Active)))*(1-Active)*exp(-alpha*beta*k*removed)+(1-(1-v*0.1)*(1-0.1*p*sumfunction(10,4,Active)))*(1-Active)*(1-exp(-alpha*beta*k*removed))-(1-(1-v*0.1)*(1-0.1*p*sumfunction(10,4,(1-Active))))*Active*exp(-beta*k*removed)-(1-(1-v*0.1)*(1-0.1*Gamma*p*sumfunction(10,4,(1-Active))))*Active*(1-exp(-beta*k*removed));
    end
    x=1;
    for ii = 2:1000
        if(Error(ii-1)*Error(ii) < 0)
            Index(i,x)=ii;
            x=x+1;
            Number(i)=Number(i)+1;
        end
    end
end
n=1;
for i=1:N+1
    for j=1:Number(i)
        r(n)=Index(i,j)*0.001;
        a(n)=(i-1)*0.002;
        n=n+1;
    end
end
end

function y=sumfunction(k,m,density)
y=0;
for i=1:m+1
    y=y+nchoosek(k,k-(i-1))*(density)^(k-(i-1))*(1-density)^(i-1);
end
end