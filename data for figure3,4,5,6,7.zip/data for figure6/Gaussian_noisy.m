clc;
clear all;
O=load('positivetimes.txt');
I=load('infectedtimes.txt');
L=load('ActualInfection.txt');
t=[0.1:0.1:400];
figure(1)
plot(t,O(1:4000),'-','Color','[0.08,0.17,0.55]','linewidth',1.5);
hold off
xlabel('t','FontName','Times New Roman','FontSize',22)
ylabel('\rho^+(t)','FontName','Times New Roman','FontSize',22)
ax=gca;
ax.FontSize=16;
figure(2)
plot(t,I(1:4000),'-','Color','[0.08,0.17,0.55]','linewidth',1.5);
hold off
xlabel('t','FontName','Times New Roman','FontSize',22)
ylabel('\rho^R(t)','FontName','Times New Roman','FontSize',22)
ax=gca;
ax.FontSize=16;
figure(3)
h=histogram(L(1:10000),'Normalization','probability');
h.NumBins=30;
xlabel('\beta(t)','FontName','Times New Roman','FontSize',22)
ylabel('Probability density','FontName','Times New Roman','FontSize',22)
ax=gca;
ax.FontSize=16;
figure(4)
plot(t(3001:4000),L(3001:4000),'-','Color','[0.08,0.17,0.55]','linewidth',1.5);
hold on
plot([300,400],[0.26,0.26],'--','Color','[0.8,0.8,0.8]','linewidth',2.0);
c=plot([300,400],[0.307,0.307],'--','Color','[0.8,0.8,0.8]','linewidth',2.5);
hold off
xlabel('t','FontName','Times New Roman','FontSize',22)
ylabel('\beta(t)','FontName','Times New Roman','FontSize',22)
ax=gca;
ax.FontSize=16;
