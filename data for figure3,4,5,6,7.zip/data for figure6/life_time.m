clc;
clear all;
tao=[1.0,1.5,2.0,2.5,3.0,3.5,4.0,4.5,5.0,5.5,6.0,7.0,8.0,9.0,10,11,12];
T=[62.912,45.988,34.391,26.715,25.175,21.694,22.704,20.738,19.801,20.563,22.759,18.397,20.918,22.035,24.889,27.930,29.9235];
figure(1)
plot(tao,T,'ro','MarkerSize',15,'MarkerFaceColor','r')
xlabel('\tau','FontName','Times New Roman','FontSize',22)
ylabel('Life Time','FontName','Times New Roman','FontSize',22)
ax=gca;
ax.FontSize=18;
figure(2)
%semilogy(tao,T./tao,'ro','MarkerSize',14,'MarkerFaceColor','r')
semilogy(tao,T./tao,'o','Color','[0.08,0.17,0.55]','MarkerSize',14,'MarkerFaceColor','[0.08,0.17,0.55]')
xlabel('\tau','FontName','Times New Roman','FontSize',22)
ylabel('T/\tau','FontName','Times New Roman','FontSize',22)
hold on
plot([0,12],[2.5967,2.5967],'k--','linewidth',2.0)
hold off
ax=gca;
ax.FontSize=18;
ax.XLim=[0 12];
ax.YLim=[1 100];