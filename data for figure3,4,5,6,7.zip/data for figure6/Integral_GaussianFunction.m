clc;
clear all;
fun=@(x,c) exp(-(x-c).^2./(2*(0.33*c).^2))./(0.33*c*sqrt(2*pi))
f=integral(@(x)fun(x,0.28),0.307,Inf)