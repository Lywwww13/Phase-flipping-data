clc;
clear all;
%load alpha=0.5.mat
S=load("Sim.mat");
T=load("theoretic.mat");
values=spcrv([[T.beta1(1) T.beta1 T.beta1(end)];[T.v1(1) T.v1 T.v1(end)]],3);
figure(2)
plot(values(1,:),values(2,:),'b-','linewidth',1.5)
hold on
plot(T.beta2,T.v2,'r-','linewidth',1.5)
plot(T.beta3,T.v3,'-','color','[0.47,0.67,0.19]','linewidth',1.5)
plot(S.Beta1,S.V1,'bs','MarkerSize',10)
plot(S.Beta2,S.V2,'ro','MarkerSize',10)
plot(S.Beta3,S.V3,'^','color','[0.47,0.67,0.19]','MarkerSize',10)
hold off
xlim([0,0.5])
ylim([0,0.5])
legend('\alpha=0.2 MF','\alpha=0.5 MF','\alpha=0.8 MF','\alpha=0.2 Sim','\alpha=0.5 Sim','\alpha=0.8 Sim','Fontname','Times New Roman');
xlabel('\beta','FontSize',22,'FontName','Times New Roman')
ylabel('\nu','FontSize',22,'FontName','Times New Roman')
ax=gca;
ax.FontSize=16;