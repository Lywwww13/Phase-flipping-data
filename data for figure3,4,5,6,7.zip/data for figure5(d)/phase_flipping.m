clc;
clear all;
AN=load('ActiveNoisy.txt');
NN=load('NegativeNoisy.txt');
P=load('positivetimes.txt');
N=[50,75,100,125,150,175,200,250];
n=[15:0.1:300];
up=90.1*exp(0.0292*n);
down=12.5*exp(0.0400*n);
UP=[271.1032,744.8721,1538.7782,3315.1658,6169.3114,14296.9824,33342.068,111929.5592];
DOWN=[107.2474,277.4711,726.7742,1914.808,5695.4228,13128.66,43416.314,268337.2865];
t=[0.1:0.1:706.3];
v1=[0.01,0.05,0.10,0.11,0.12,0.13,0.14,0.15,0.16,0.17,0.18,0.19,0.20,0.22,0.24,0.26,0.28,0.30,0.32,0.33,0.335,0.337,0.342,0.337,0.335,0.33,0.32,0.31,0.30,0.29,0.28,0.27,0.26,0.25,0.24,0.23,0.22,0.21,0.20,0.19];
v2=[0.147,0.168,0.194,0.2,0.205,0.210,0.216,0.222,0.228,0.234,0.240,0.247,0.253,0.267,0.281,0.295,0.311,0.327,0.345,0.354,0.359,0.361,0.364,0.356,0.352,0.345,0.331,0.315,0.296,0.277,0.257,0.237,0.212,0.187,0.160,0.135,0.110,0.08,0.04,0.01];
figure(1)
plot(v1,v2,'b-','linewidth',1.5)
hold on
plot(AN(30000:31675),NN(30000:31675),'k-');
plot(AN(37880),NN(37880),'ko','MarkerSize',15,'MarkerFaceColor','g')
plot(AN(7056),NN(7056),'ko','MarkerSize',15,'MarkerFaceColor','r')
figure(2)
plot(t(1:end),P(1:end),'b-')
hold on
plot(t(37880),P(37880),'ko','MarkerSize',15,'MarkerFaceColor','g')
plot(t(7056),P(7056),'ko','MarkerSize',15,'MarkerFaceColor','g')
hold off
figure(3)
h1=semilogy(N,UP,'ko','MarkerSize',10,'MarkerFaceColor','y');
hold on
h2=semilogy(N,DOWN,'ko','MarkerSize',10,'MarkerFaceColor','[0.08,0.17,0.55]');%[0.08,0.17,0.55]
plot(n,up,'k-','linewidth',1.5)
plot(n,down,'k-','linewidth',1.5)
hold off
legend([h1,h2],'UP','DOWN','Location','northwest','FontName','Times New Roman','FontSize',10)
legend('boxoff')
xlabel('\itN','FontName','Times New Roman','FontSize',22)
ylabel('\itT','FontName','Times New Roman','FontSize',22)
xlim([0 350])
ylim([10 8000000])
ax=gca;
ax.FontSize=16;